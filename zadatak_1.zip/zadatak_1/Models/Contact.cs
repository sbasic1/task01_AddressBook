﻿using System;
using System.Collections.Generic;

namespace ActualIT.Models
{
    public partial class Contact
    {
        public string Name { get; set; } = null!;
        public string Surname { get; set; } = null!;
        public string Address { get; set; } = null!;
        
        public string TelephoneNum { get; set; } = null!;
    }
}
