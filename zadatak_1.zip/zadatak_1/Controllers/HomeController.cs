﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using zadatak_1.Models;
using ActualIT.Models;

namespace zadatak_1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public ActionResult MessageBox()
        {
            ViewData["msg"] = "That contact already exists";
            return View();
        }

        public ActionResult DeleteContact(string telephoneNum)
        {
            var context = new ActualITContext();

            Contact contactDel = context.Contacts.First(x => x.TelephoneNum == telephoneNum);

            context.Contacts.Remove(contactDel);
            context.SaveChanges();
            
            return RedirectToAction("ContactsList");
        }

        [HttpPost]
        public ActionResult EditContact(Contact editedContact)
        {
            var context = new ActualITContext();

            Contact chgContact = context.Contacts.Where(x => x.TelephoneNum == editedContact.TelephoneNum).First();

            chgContact.Name = editedContact.Name;
            chgContact.Surname = editedContact.Surname;
            chgContact.Address = editedContact.Address;
            
            context.SaveChanges();

            return RedirectToAction("ContactsList");
        }

        public ActionResult EditContact(string telephoneNum)
        {
            var context = new ActualITContext();

            Contact contactEdit = context.Contacts.Where(x => x.TelephoneNum == telephoneNum).First();

            //context.Contacts.Remove(contactDel);
            //context.SaveChanges();

            //return RedirectToAction("ContactsList");
            return View(contactEdit);
        }

        public ActionResult Details(string telephoneNum)
        {
            var context = new ActualITContext();

            Contact contactEdit = context.Contacts.Where(x => x.TelephoneNum == telephoneNum).First();

            //context.Contacts.Remove(contactDel);
            //context.SaveChanges();
            ViewData["editContact"] = contactEdit;
            //return RedirectToAction("ContactsList");
            //return View();
            return View(contactEdit);
        }
        [HttpPost]
        public ActionResult SearchContacts(Contact searchContact)
        {
            var context = new ActualITContext();
            string query = "";
            if (searchContact.Address != "enter text")
                query = "address='" + searchContact.Address + "'";
            if (searchContact.Name != "enter text")
            {
                if (query != "")
                    query += " AND name='" + searchContact.Name + "'";
                else
                    query += "name='" + searchContact.Name + "'";
            }
            if (searchContact.Surname != "enter text")
            {
                if (query != "")
                    query += " AND surname='" + searchContact.Surname + "'";
                else
                    query += "surname='" + searchContact.Surname + "'";
            }
            if (searchContact.TelephoneNum != "enter text")
            {
                if (query != "")
                    query += " AND telephone_num='" + searchContact.TelephoneNum + "'";
                else
                    query += "telephone_num='" + searchContact.TelephoneNum + "'";
            }
            var contactsList = context.Contacts.FromSqlRaw("Select * from contacts where " + query)
                        .ToList<Contact>();

            ViewData["contacts"] = contactsList;
            return View("SearchResults");
        }

        public ActionResult SearchContacts()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateContact(Contact newContact)
        {
            var context = new ActualITContext();

            var r = context.Contacts.Where(m => m.TelephoneNum == newContact.TelephoneNum).FirstOrDefault();
            if (r == null)
            {
                context.Contacts.Add(newContact);
                context.SaveChanges();
            }
            else
            {
                
                return RedirectToAction("MessageBox");//You can show a message on a label to tell others that you have a duplicated primary key...
            }

            return RedirectToAction("ContactsList");
        }
        
        public ActionResult CreateContact()
        {
            //fetch students from the DB using Entity Framework here

            //IList<Contacts> contactsList = new List<Contact>();
          
            return View();
        }

        public ActionResult ContactsList()
        {
            //fetch students from the DB using Entity Framework here

            //IList<Contacts> contactsList = new List<Contact>();
            var context = new ActualITContext();
            IList<Contact> contactsList = context.Contacts
                                              .ToList();

            return View(contactsList);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}